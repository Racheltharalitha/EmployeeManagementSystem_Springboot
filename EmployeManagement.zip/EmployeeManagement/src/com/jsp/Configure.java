package com.jsp;

public class Configure {

}
