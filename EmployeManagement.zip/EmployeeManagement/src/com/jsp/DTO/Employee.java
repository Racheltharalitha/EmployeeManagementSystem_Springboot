package com.jsp.DTO;

public class Employee {

}
