package com.jsp.INITIALIZER;

public class Employeeintializer {

}
